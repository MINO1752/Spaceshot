#라이브러리 불러오기
import pygame, time, random

#이 프로그램에 사용할 키를 pygame에서 불러오기
from pygame.locals import (
    K_UP,
    K_DOWN,
    K_LEFT,
    K_RIGHT,
    K_SPACE,
    K_0,
    K_1,
    K_2,
    K_3,
    K_SLASH,
    K_ESCAPE,
    KEYDOWN,
    KEYUP,
    QUIT,
)

#pygame 초기화
pygame.init()

#화면 크기 설정
screen_width = 500
screen_height = 1000
screen = pygame.display.set_mode([screen_width,screen_height])

#텍스트 폰트 설정
MyFont20 = pygame.font.SysFont(None, 20)
MyFont50 = pygame.font.SysFont(None, 50)
MyFont100 = pygame.font.SysFont(None, 100)

#시간 설정
clock = pygame.time.Clock()

#객체 이미지 설정
player_img = pygame.image.load("./player.png")
player_bullet_img = pygame.image.load("./player_bullet.png")

blitz_imgs = [pygame.image.load("./blitz_0.png"),pygame.image.load("./blitz_1.png")]

shooter_imgs = [pygame.image.load("./shooter_0.png"),pygame.image.load("./shooter_1.png")]
shooter_bullet_img = pygame.image.load("./shooter_bullet.png")

beetle_imgs = [pygame.image.load("./beetle_0.png"),pygame.image.load("./beetle_1.png")]

boom_imgs = [pygame.image.load("./boom_0.png"),pygame.image.load("./boom_1.png"),pygame.image.load("./boom_2.png"),
             pygame.image.load("./boom_3.png"),pygame.image.load("./boom_4.png"),pygame.image.load("./boom_5.png")
             ]

background_imgs = [pygame.image.load("./background_0.png"),pygame.image.load("./background_1.png")]

####################################################################################################

#플레이어 클래스
class Player:

    #파라미터
    def __init__(self, pos):
        self.pos = pos
        self.shoot_ctime_0 = 15
        self.shoot_ctime = self.shoot_ctime_0

    #움직이기
    def move(self):
        if pressed_keys[K_UP] and self.pos[1] > 16:
            self.pos[1] -= 4
        if pressed_keys[K_DOWN] and self.pos[1] < screen_height - 16:
            self.pos[1] += 4
        if pressed_keys[K_LEFT]:
            self.pos[0] -= 4
            if self.pos[0] < 0:    #좌우 화면 연결
                self.pos[0] += screen_width
        if pressed_keys[K_RIGHT]:
            self.pos[0] += 4
            if self.pos[0] > screen_width: #좌우 화면 연결
                self.pos[0] -= screen_width
    
    #그리기
    def draw(self):
        screen.blit(player_img, (self.pos[0]-16, self.pos[1]-16))

    #쏘기
    def shoot(self):
        if self.shoot_ctime > 0:
            self.shoot_ctime -=1
        elif pressed_keys[K_SLASH]:
            bullets.append(Player_Bullet(self.pos.copy()))
            self.shoot_ctime = self.shoot_ctime_0   

####################################################################################################

#플레이어 총알 클래스
class Player_Bullet:

    #파라미터
    def __init__(self, pos):
        self.pos = pos
        self.type = "Player_Bullet"

    #움직이기
    def move(self):
        if self.pos[1] -16 <= 0:
            bullets.remove(self)
        else:
            self.pos[1] -= 6
    #그리기
    def draw(self):
        screen.blit(player_bullet_img, (self.pos[0]-16, self.pos[1]-16))

####################################################################################################

#비틀 클래스
class Beetle:

    #파라미터
    def __init__(self, pos):
        self.pos = pos
        self.form = 0
        self.form_time = 40
        self.type = "Beetle"

    #움직이기, 바닥에 닿으면 사라지기
    def move(self):
        if self.pos[1] + 12 > screen_height:
            enemies.remove(self)
        else:
            self.pos[1] += 3

    #모습 바꾸기, 그리기
    def draw(self):
        self.form_time -= 1
        if self.form_time <= 0:
            self.form_time = 40
            if self.form == 0:
                self.form = 1
            else:
                self.form = 0

        screen.blit(beetle_imgs[self.form], (self.pos[0]-16, self.pos[1]-16))

    #쏘기 명령어 건너뛰기
    def shoot(self):
        pass

####################################################################################################

#블리츠 클래스
class Blitz:

    #파라미터
    def __init__(self, pos):
        self.pos = pos
        self.form = 0
        self.form_time = 60
        self.type = "Blitz"

    #움직이기, 바닥에 닿으면 사라지기
    def move(self):
        if self.pos[1] + 16 > screen_height:
            enemies.remove(self)
        else:
            self.pos[1] += 2

    #모습 바꾸기, 그리기
    def draw(self):
        self.form_time -= 1
        if self.form_time <= 0:
            self.form_time = 60
            if self.form == 0:
                self.form = 1
            else:
                self.form = 0

        screen.blit(blitz_imgs[self.form], (self.pos[0]-16, self.pos[1]-16))

    #쏘기 명령어 건너뛰기
    def shoot(self):
        pass

####################################################################################################

#슈터 클래스
class Shooter:

    #파라미터
    def __init__(self, pos):
        self.pos = pos
        self.form = 0
        self.form_time = 30
        self.shoot_ctime_0 = 120
        self.shoot_ctime = 0
        self.type = "Shooter"
        self.level = 1

    #움직이기, 바닥에 닿으면 사라지기
    def move(self):
        if self.pos[1] + 16 > screen_height:
            enemies.remove(self)
        else:
            self.pos[1] += 1

    #모습 바꾸기, 그리기
    def draw(self):
        self.form_time -= 1
        if self.form_time <= 0:
            self.form_time = 30
            if self.form == 0:
                self.form = 1
            else:
                self. form = 0

        screen.blit(shooter_imgs[self.form], (self.pos[0]-16, self.pos[1]-16))

    #쏘기
    def shoot(self):
        if self.shoot_ctime > 0:
            self.shoot_ctime -=1
        else:
            bullets.append(Shooter_Bullet(self.pos.copy()))
            self.shoot_ctime = self.shoot_ctime_0

####################################################################################################

#슈터 총알 클래스
class Shooter_Bullet:

    #파라미터
    def __init__(self, pos):
        self.pos = pos
        self.type = "Shooter_Bullet"

    #움직이기
    def move(self):
        if self.pos[1] + 16 > screen_height:
            bullets.remove(self)
        else:
            self.pos[1] += 4

    #그리기
    def draw(self):
        screen.blit(shooter_bullet_img, (self.pos[0]-16, self.pos[1]-16))

####################################################################################################

#폭발 이미지 클래스
class Boom:

    #파라미터
    def __init__(self, pos):
        self.pos = pos
        self.form = 0
        self.form_time = 10

    #움직이기
    def move(self):
        self.pos[1] += 1

    #모습 바꾸기, 그리기
    def draw(self):
        screen.blit(boom_imgs[self.form], (self.pos[0]-16, self.pos[1]-16))
        self.form_time -= 1
        if self.form_time <= 0:
            self.form_time = 10
            self.form += 1
        if self.form == 6:
            booms.remove(self)
        
####################################################################################################

#총알 접촉 관련
def Bullet_hit():
    for enemy in enemies:
        for bullet in bullets:

            #플레이어의 총알이 적에 닿으면 총알과 적 사라지고 점수 얻고 폭발 효과 생성
            if bullet.type == "Player_Bullet":
                if enemy.pos[0] - 20 < bullet.pos[0] < enemy.pos[0] + 20 and \
                enemy.pos[1] - 20 < bullet.pos[1] < enemy.pos[1] + 20:
                    bullets.remove(bullet)
                    global score
                    if enemy.type == "Beetle":
                        score += 50
                    elif enemy.type == "Blitz":
                        score += 100
                    elif enemy.type == "Shooter":
                        score += 300
                    booms.append(Boom(enemy.pos.copy()))
                    enemies.remove(enemy)

            #슈터의 총알이 플레이어에게 닿으면 플레이 루프 탈출, 마침 루프 실행
            if bullet.type == "Shooter_Bullet":
                if bullet.pos[0] - 20 <= player.pos[0] <= bullet.pos[0] + 20 and \
                bullet.pos[1] - 20 <= player.pos[1] <= bullet.pos[1] + 20:
                    global playing, finished
                    playing = False
                    finished = True

#적이 플레이어에 닿으면 플레이 루프 탈출, 마침 루프 실행
def EtoP_hit():
    for enemy in enemies:
        if enemy.pos[0] - 32 <= player.pos[0] <= enemy.pos[0] + 32 and \
        enemy.pos[1] - 32 <= player.pos[1] <= enemy.pos[1] + 32:
            global playing, finished
            playing = False
            finished = True

####################################################################################################

#적 생성
def Sumn():

    #직접 비틀 생성
    def Self_Sumn_Beetle():
        global pressed_1
        if pressed_1 and not pressed_keys[K_1]:
            pressed_1 = False
        if not pressed_1 and pressed_keys[K_1]:
            enemies.append(Beetle([mouse_pos[0], 0]))
            pressed_1 = True

    #직접 블리츠 생성
    def Self_Sumn_Blitz():
        global pressed_2
        if pressed_2 and not pressed_keys[K_2]:
            pressed_2 = False
        if not pressed_2 and pressed_keys[K_2]:
            enemies.append(Blitz([mouse_pos[0], 0]))
            pressed_2 = True

    #직접 슈터 생성
    def Self_Sumn_Shooter():
        global pressed_3
        if pressed_3 and not pressed_keys[K_3]:
            pressed_3 = False
        if not pressed_3 and pressed_keys[K_3]:
            enemies.append(Shooter([mouse_pos[0], 0]))
            pressed_3 = True

    #자동 비틀 생성
    def Auto_Sumn_Beetle():
        global Sumn_Beetle_time
        if Sumn_Beetle_time == 0:
            enemies.append(Beetle([random.randrange(16, screen_width - 16, 1), 0]))
            Sumn_Beetle_time = waves[current_wave][1]
        
        if Sumn_Beetle_time >0:
            Sumn_Beetle_time -= 1

    #자동 블리츠 생성
    def Auto_Sumn_Blitz():
        global Sumn_Blitz_time
        if Sumn_Blitz_time == 0:
            enemies.append(Blitz([random.randrange(16, screen_width - 16, 1), 0]))
            Sumn_Blitz_time = waves[current_wave][2]
        
        if Sumn_Blitz_time >0:
            Sumn_Blitz_time -= 1

    #자동 슈터 생성
    def Auto_Sumn_Shooter():
        global Sumn_Shooter_time
        if Sumn_Shooter_time == 0:
            enemies.append(Shooter([random.randrange(16, screen_width - 16, 1), 0]))
            Sumn_Shooter_time = waves[current_wave][3]

        if Sumn_Shooter_time >0:
            Sumn_Shooter_time -= 1

    #적 생성 명령어 실행
    Self_Sumn_Beetle()
    Auto_Sumn_Beetle()
    Self_Sumn_Blitz()
    Self_Sumn_Shooter()
    Auto_Sumn_Blitz()
    Auto_Sumn_Shooter()
    
####################################################################################################

#웨이브 넘기기
def Pass_Wave():

    #직접 웨이브 넘기기
    def Self_Pass_Wave():
            global pressed_0, wave_time, Sumn_Beetle_time, Sumn_Blitz_time, Sumn_Shooter_time
            if pressed_0 and not pressed_keys[K_0]:
                pressed_0 = False
            if not pressed_0 and pressed_keys[K_0]:
                if current_wave != len(waves)-1:
                    wave_time = 0
                    Sumn_Beetle_time = waves[current_wave][1]
                    Sumn_Blitz_time = waves[current_wave][2]
                    Sumn_Shooter_time = waves[current_wave][3]
                    pressed_0 = True

    #자동 웨이브 넘기기
    def Auto_Pass_Wave():
        global wave_time, current_wave, Sumn_Beetle_time, Sumn_Blitz_time, Sumn_Shooter_time
        if current_wave != len(waves)-1:
            if wave_time == 0:
                current_wave += 1
                wave_time = waves[current_wave][0]
                Sumn_Beetle_time = waves[current_wave][1]
                Sumn_Blitz_time = waves[current_wave][2]
                Sumn_Shooter_time = waves[current_wave][3]
            wave_time -= 1
    
    #웨이브 넘기기 명령어 실행
    Self_Pass_Wave()
    Auto_Pass_Wave()

####################################################################################################

#우주 배경 그리기
def Background_Draw():
    global background_time
    screen.blit(background_imgs[0], (0,(background_time + 1000) % 2000 - 1000))
    screen.blit(background_imgs[1], (0,background_time % 2000 - 1000))
    background_time += 0.5

####################################################################################################

#게임 진행 설명
def main():

    #루프 트리거
    global running, waiting, playing, finished
    running = False
    waiting = False
    playing = False
    finished = False

    #메인 루프 실행
    running = True

####################################################################################################

    #메인 루프
    while running:

####################################################################################################

        #여러 전역 변수 설정
        global player, enemies, bullets, booms, score, pressed_0, pressed_1, pressed_2, pressed_3, Sumn_Beetle_time, Sumn_Blitz_time, Sumn_Shooter_time, waves, current_wave, wave_time, background_time

        #기다림 루프에 쓰이는 변수 설정
        player = Player([250, 600])
        enemies = [Beetle([120, 700]), Blitz([250, 700]), Shooter([380, 700])]
        bullets = []
        booms = []
        score = 0

        #기다림 루프 실행
        waiting = True

        #기다림 루프
        while waiting:
            
            #나가기 버튼 눌렀다면 모든 루프 탈출
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    waiting = False
                    playing = False
                    finished = False

                #스페이스 바 눌렀다면 기다림 루프 탈출, 플레이 루프 실행
                if event.type == KEYDOWN:
                    if event.key == K_SPACE:
                        waiting = False
                        playing = True


            #현재 누른 키, 마우스 위치 입력받기
            global pressed_keys, mouse_pos
            pressed_keys = pygame.key.get_pressed()
            mouse_pos = pygame.mouse.get_pos()
            
            #배경 색칠하기
            screen.fill((0,0,0))


            #플레이어 행동
            player.move()
            player.draw()
            player.shoot()
            
            #총알 행동
            for bullet in bullets:
                bullet.move()
                bullet.draw()

            #적 행동
            for enemy in enemies:
                enemy.draw()

            #폭발 행동
            for boom in booms:
                boom.draw()

            #총알 접촉 관련
            Bullet_hit()

            #게임 타이틀 표시하기
            text_title = MyFont100.render("[SpaceShot]", True, (0,183,239))
            screen.blit(text_title, (45, 100))

            #조작 방법 표시하기
            text_manual = MyFont20.render("Arrow Keys to Move | Slash to Shoot | 1, 2 to Spawn Enemies", False, (255,255,255))
            screen.blit(text_manual, (50,250))

            #게임 시작 권유 표시하기
            text_start = MyFont50.render("Press Space Bar to Start", True, (255,255,255))
            screen.blit(text_start, (50,400))

            #플레이어 소개 텍스트
            text_player = MyFont20.render("You", False, (255,255,255))
            screen.blit(text_player, (238, 650))

            #적 소개 텍스트
            text_beetle = MyFont20.render("Beetle: 50 Point", False, (255,255,255))
            text_blitz = MyFont20.render("Blitz: 100 Point", False, (255,255,255))
            text_shooter = MyFont20.render("Shooter: 300 Point", False, (255,255,255))
            screen.blit(text_beetle, (70, 750))
            screen.blit(text_blitz, (200, 750))
            screen.blit(text_shooter, (330, 750))

            #화면 갱신하기
            pygame.display.flip()

            #시간 흐르기
            clock.tick(60)

####################################################################################################

        #여러 전역 변수 설정
        

        #여러 변수 초기 설정
        player = Player([screen_width/2, screen_height - 112])
        enemies = []
        bullets = []
        booms = []
        score = 0
        pressed_0 = False
        pressed_1 = False
        pressed_2 = False
        pressed_3 = False
        Sumn_Beetle_time = -1
        Sumn_Blitz_time = -1
        Sumn_Shooter_time = -1
        waves = [[300,-1,-1,-1],
                 [600,150,-1,-1],[600,130,-1,-1],[600,110,-1,-1],
                 [900,95,300,-1],[900,80,260,-1],[900,67,220,-1],
                 [1200,55,185,400],[1200,44,152,350],[1200,34,127,300],[0,25,100,250]
                 ] #[웨이브 시간, 비틀, 블리츠, 슈터 소환 시간]
        current_wave = 0
        wave_time = waves[current_wave][0]
        background_time = 0

        #플레이 루프
        while playing:

            #나가기 버튼 눌렀다면 모든 루프 탈출
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    waiting = False
                    playing = False
                    finished = False
            
            #현재 누른 키, 마우스 위치 입력받기
            pressed_keys = pygame.key.get_pressed()
            mouse_pos = pygame.mouse.get_pos()
            
            #배경 색칠하기
            screen.fill((0,0,0))

            #우주 배경 그리기
            Background_Draw()

            #플레이어 행동
            player.move()
            player.draw()
            player.shoot()
            
            #총알 행동
            for bullet in bullets:
                bullet.move()
                bullet.draw()

            #적 행동
            for enemy in enemies:
                enemy.move()
                enemy.draw()
                enemy.shoot()

            #폭발 행동
            for boom in booms:
                boom.move()
                boom.draw()


            #적 생성
            Sumn()


            #적이 플레이어에 닿으면 플레이 루프 탈출, 마침 루프 실행
            EtoP_hit()
            #총알 접촉 관련
            Bullet_hit()

            #웨이브 넘기기
            Pass_Wave()
            

            #조준선
            #pygame.draw.rect(screen, (100,0,0), [player.pos[0]+14,player.pos[1]-1000, 4, 1000])


            #현재 점수 표시
            text_CurrentScore = MyFont50.render(str(score), True, (255,255,255))
            screen.blit(text_CurrentScore, (0,screen_height - 50))

            #현재 웨이브 표시
            text_CurrentWave = MyFont50.render("Current Wave: %d" %current_wave, True, (255,255,255))
            screen.blit(text_CurrentWave, (200,screen_height - 50))

            #다음 웨이브 시작 시간 표시
            text_WaveTime = MyFont20.render("next wave is starting at: {}".format(round(wave_time/60, 1)), True, (255,255,255))
            screen.blit(text_WaveTime, (200,screen_height - 70))

            #화면 갱신하기
            pygame.display.flip()

            #시간(틱) 흐르기
            clock.tick(60)

####################################################################################################
        
        #모든 폭발 지우고 플레이어가 죽은 자리에 폭발 생성
        booms = []
        booms.append(Boom(player.pos.copy()))

        #마침 루프
        while finished:

            #나가기 버튼 눌렀다면 모든 루프 탈출
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    waiting = False
                    playing = False
                    finished = False
            
            #배경 색칠하기
            screen.fill((0,0,0))

            #폭발 행동
            for boom in booms:
                boom.draw()

            #게임 오버 표시하기
            text_GameOver = MyFont50.render("Game Over!", True, (255,255,255))
            screen.blit(text_GameOver, (160,225))

            #최종 점수 표시하기
            text_FinalScore = MyFont50.render("Score: %d" %score, False, (255,255,255))
            screen.blit(text_FinalScore, (160,300))

            #화면 갱신하기
            pygame.display.flip()
            
            #시간 흐르기
            clock.tick(60)

####################################################################################################

    #모든 루프가 끝났다면 게임 종료
    pygame.quit()

####################################################################################################

#게임 시작
if __name__ == "__main__":
    main()


#배경 추가 V
#점수 표시기, 리더보드
#적 추가 V
#체력 시스템
#웨이브 시스템 V
#우주선 진화